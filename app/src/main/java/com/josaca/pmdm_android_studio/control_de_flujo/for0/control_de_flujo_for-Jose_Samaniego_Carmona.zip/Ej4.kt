package com.josaca.pmdm_android_studio.control_de_flujo.for0

fun main() {
    var suma = 0

    for (i in 1..100) {
        suma += i
    }

    print(suma)
}